<?php

return array(
    'client_tabs' => array(
        'sophos' => array('view' => 'sophos_client_tab', 'i18n' => 'sophos.client_tab'),
    ),
    'listings' => array(
        'sophos' => array('view' => 'sophos_listing', 'i18n' => 'sophos.sophos'),
    ),
    'widgets' => array(),
    'reports' => array(),
);
